function createMockTask() {
  return {
    id: "debug-001",
    title: "Add a utility function to format dates",
    content: `<p>Create a new utility function in the project that formats dates in a human-readable way.</p>
<p>The function should:</p>
<ul>
<li>Accept a Date object as input</li>
<li>Return a string in the format "DD/MM/YYYY HH:MM"</li>
<li>Handle invalid dates gracefully (return "Invalid date")</li>
<li>Be exported from a utils.js file</li>
</ul>`,
    tasks_comments: [],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

function createMockConfig() {
  return {
    matilda_api_url: "http://localhost:3000",
    matilda_api_key: "debug-key-not-used",
  };
}

module.exports = { createMockTask, createMockConfig };
