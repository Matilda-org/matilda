const { SERVICE_NAME } = require("../lib/api");

function buildPlannerPrompt(task, instructions) {
  let prompt = "";

  if (instructions) {
    prompt += `## Custom Instructions\n\n${instructions}\n\n`;
  }

  prompt += `## Role\n\n`;
  prompt += `You are a PLANNER agent. Your job is to analyze the task below and create a detailed plan with sub-tasks.\n\n`;

  prompt += `## Task\n\n`;
  prompt += `**Title:** ${task.title}\n\n`;

  if (task.content) {
    const cleanContent = task.content.replace(/<[^>]*>/g, "").trim();
    if (cleanContent) {
      prompt += `**Description:**\n${cleanContent}\n\n`;
    }
  }

  if (task.tasks_comments && task.tasks_comments.length > 0) {
    prompt += `## Conversation History\n\n`;
    const sorted = [...task.tasks_comments].sort(
      (a, b) => new Date(a.created_at) - new Date(b.created_at)
    );
    for (const comment of sorted) {
      const author = comment.service === SERVICE_NAME ? "OpenCode Agent" : "User";
      const date = new Date(comment.created_at).toLocaleString();
      prompt += `**${author}** (${date}):\n${comment.content}\n\n`;
    }
  }

  prompt += `## Instructions\n\n`;
  prompt += `1. Analyze the task thoroughly\n`;
  prompt += `2. Break it down into clear, actionable sub-tasks\n`;
  prompt += `3. Identify dependencies between sub-tasks\n`;
  prompt += `4. Define acceptance criteria for each sub-task\n`;
  prompt += `5. Create a file named "TASK-PLAN.md" in the repository root with the complete plan\n\n`;

  prompt += `## Plan Format\n\n`;
  prompt += `# Task Plan: ${task.title}\n\n`;
  prompt += `## Overview\n{brief summary}\n\n`;
  prompt += `## Sub-tasks\n\n`;
  prompt += `### 1. {sub-task name}\n`;
  prompt += `- Description: ...\n`;
  prompt += `- Acceptance criteria: ...\n`;
  prompt += `- Dependencies: ...\n\n`;
  prompt += `### 2. ...\n\n`;
  prompt += `## Notes\n{any additional considerations}\n`;

  return prompt;
}

function buildDeveloperPrompt(task, instructions, planOutput) {
  let prompt = "";

  if (instructions) {
    prompt += `## Custom Instructions\n\n${instructions}\n\n`;
  }

  prompt += `## Role\n\n`;
  prompt += `You are a DEVELOPER agent. Your job is to implement the task according to the plan.\n\n`;

  prompt += `## Task\n\n`;
  prompt += `**Title:** ${task.title}\n\n`;

  if (task.content) {
    const cleanContent = task.content.replace(/<[^>]*>/g, "").trim();
    if (cleanContent) {
      prompt += `**Description:**\n${cleanContent}\n\n`;
    }
  }

  if (task.tasks_comments && task.tasks_comments.length > 0) {
    prompt += `## Conversation History\n\n`;
    const sorted = [...task.tasks_comments].sort(
      (a, b) => new Date(a.created_at) - new Date(b.created_at)
    );
    for (const comment of sorted) {
      const author = comment.service === SERVICE_NAME ? "OpenCode Agent" : "User";
      const date = new Date(comment.created_at).toLocaleString();
      prompt += `**${author}** (${date}):\n${comment.content}\n\n`;
    }
  }

  prompt += `## Plan\n\n`;
  prompt += planOutput;
  prompt += `\n\n`;

  prompt += `## Instructions\n\n`;
  prompt += `1. Follow the plan above and implement each sub-task\n`;
  prompt += `2. Follow best practices and existing code conventions\n`;
  prompt += `3. Test your changes locally\n`;
  prompt += `4. Create a file named "TASK-REPORT.md" in the repository root with a summary of what you did\n\n`;

  prompt += `## Report Format\n\n`;
  prompt += `# Task Report: ${task.title}\n\n`;
  prompt += `## REVIEW_STATUS: PENDING_REVIEW\n\n`;
  prompt += `## Summary\n{what was implemented}\n\n`;
  prompt += `## Changes Made\n\n`;
  prompt += `- {file}: {description}\n`;
  prompt += `- ...\n\n`;
  prompt += `## Sub-tasks Status\n\n`;
  prompt += `### 1. {sub-task name}\n`;
  prompt += `- Status: COMPLETED / PARTIAL / SKIPPED\n`;
  prompt += `- Notes: ...\n\n`;
  prompt += `## Testing\n{tests run}\n\n`;
  prompt += `## Known Issues\n{any known issues}\n`;

  return prompt;
}

function buildDeveloperRevisionPrompt(task, instructions, planOutput, reviewFeedback) {
  let prompt = "";

  if (instructions) {
    prompt += `## Custom Instructions\n\n${instructions}\n\n`;
  }

  prompt += `## Role\n\n`;
  prompt += `You are a DEVELOPER agent. Your work was reviewed and needs revisions.\n\n`;

  prompt += `## Task\n\n`;
  prompt += `**Title:** ${task.title}\n\n`;

  prompt += `## Original Plan\n\n`;
  prompt += planOutput;
  prompt += `\n\n`;

  prompt += `## Review Feedback\n\n`;
  prompt += reviewFeedback;
  prompt += `\n\n`;

  prompt += `## Instructions\n\n`;
  prompt += `1. Fix all issues mentioned in the review feedback\n`;
  prompt += `2. Update your code accordingly\n`;
  prompt += `3. Update the TASK-REPORT.md file with the changes you made\n`;
  prompt += `4. Keep REVIEW_STATUS: PENDING_REVIEW in the report so it can be reviewed again\n`;

  return prompt;
}

function buildReviewerPrompt(task, planOutput, developerOutput) {
  let prompt = "";

  prompt += `## Role\n\n`;
  prompt += `You are a REVIEWER agent. Review the code implemented by the developer.\n\n`;

  prompt += `## Task\n\n`;
  prompt += `**Title:** ${task.title}\n\n`;

  if (task.content) {
    const cleanContent = task.content.replace(/<[^>]*>/g, "").trim();
    if (cleanContent) {
      prompt += `**Description:**\n${cleanContent}\n\n`;
    }
  }

  prompt += `## Plan\n\n`;
  prompt += planOutput;
  prompt += `\n\n`;

  prompt += `## Developer Report\n\n`;
  prompt += developerOutput;
  prompt += `\n\n`;

  prompt += `## Instructions\n\n`;
  prompt += `1. Read the plan and the developer's report\n`;
  prompt += `2. Examine the actual code in the repository to verify implementation\n`;
  prompt += `3. Check that all sub-tasks were properly implemented\n`;
  prompt += `4. Verify code quality, conventions, and correctness\n`;
  prompt += `5. Check for edge cases, error handling, and potential bugs\n\n`;

  prompt += `## Output\n\n`;
  prompt += `Respond with your review. Start your response with one of:\n`;
  prompt += `- "REVIEW_STATUS: APPROVED" if everything is correct, followed by your positive feedback\n`;
  prompt += `- "REVIEW_STATUS: NEEDS_REVISION" if something needs fixing, followed by detailed feedback with file references and suggested fixes\n`;

  return prompt;
}

module.exports = {
  buildPlannerPrompt,
  buildDeveloperPrompt,
  buildDeveloperRevisionPrompt,
  buildReviewerPrompt,
};
