#!/usr/bin/env node

const { log, logError } = require("./lib/logger");
const { loadConfig, loadInstructions } = require("./lib/config");
const { ping, fetchTasks, fetchTaskDetails, postComment, isLastCommentFromOpenCode, SERVICE_NAME } = require("./lib/api");
const { orchestrateTask } = require("./lib/orchestrator");
const { createMockTask } = require("./debug");

const LOOP_INTERVAL_MS = 30_000;

const DEBUG_MODE = process.argv.includes("--debug") || process.env.DEBUG_MODE === "true";

const completedTasks = new Set();

async function processTask(config, task, instructions) {
  const status = await orchestrateTask(task, instructions, config, postComment);
  if (status === "approved" || status === "max_revisions_reached" || status === "error") {
    completedTasks.add(task.id);
  }
}

async function mainLoop() {
  const config = loadConfig();
  const instructions = loadInstructions();

  log("OpenCode Integration started");
  log(`API URL: ${config.matilda_api_url}`);
  log(`Debug mode: ${DEBUG_MODE ? "ON" : "OFF"}`);

  if (DEBUG_MODE) {
    log("Running in DEBUG mode with mock task");
    const mockTask = createMockTask();
    try {
      await processTask(config, mockTask, instructions);
      log("Debug task completed");
    } catch (err) {
      logError(`Debug task failed: ${err.message}`);
    }
    return;
  }

  while (true) {
    try {
      await ping(config);

      const taskList = await fetchTasks(config);
      log(`Found ${taskList.length} task(s) to process`);

      for (const taskSummary of taskList) {
        const task = await fetchTaskDetails(config, taskSummary.id);
        if (!task) continue;

        if (completedTasks.has(task.id) && isLastCommentFromOpenCode(task)) {
          log(`Task ${task.id}: already processed, waiting for user feedback, skipping`);
          continue;
        }

        if (completedTasks.has(task.id)) {
          log(`Task ${task.id}: user replied, re-processing`);
          completedTasks.delete(task.id);
        }

        await processTask(config, task, instructions);
      }
    } catch (err) {
      logError(`Main loop error: ${err.message}`);
    }

    await new Promise((resolve) => setTimeout(resolve, LOOP_INTERVAL_MS));
  }
}

mainLoop().catch((err) => {
  logError(`Fatal error: ${err.message}`);
  process.exit(1);
});
